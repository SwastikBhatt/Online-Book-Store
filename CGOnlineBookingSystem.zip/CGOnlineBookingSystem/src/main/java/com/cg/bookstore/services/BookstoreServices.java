package com.cg.bookstore.services;

import java.util.List;

import com.cg.bookstore.beans.Books;
import com.cg.bookstore.exception.BookISBNAlreadyExistsException;
import com.cg.bookstore.exception.BookISBNNotFoundException;

public interface BookstoreServices {
	Books acceptBookDetails(Books book);
	List<Books> getAllBookDetails();

	boolean removeAssociateDetails(String bookISBN) throws BookISBNAlreadyExistsException;
	Books getBookDetails(String bookISBN)throws BookISBNNotFoundException;
}
